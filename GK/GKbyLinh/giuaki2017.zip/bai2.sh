#!/bin/bash
ls /etc | grep -E "^ap.*" > Output1.txt