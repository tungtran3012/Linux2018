#!/bin/bash
i=1
while [ $i != 5 ]
do 
	#echo "In ra lan $i"
	i=`expr $i + 1`
done
