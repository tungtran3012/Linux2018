#include <stdio.h>
#include "sum.h"
int main(int argc, char **argv) {
  int x;
  x = sum(1, 2);
  printf("x = %d\n", x);
  return 1;
}
