#!/bin/bash
javac FibonacciTest.java 
java FibonacciTest

